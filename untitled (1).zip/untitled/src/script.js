// Smooth scroll function

function scrollToSection(id) {

  document.getElementById(id).scrollIntoView({ behavior: "smooth" });

}

// Optional: Add a small animation or alert when form is submitted

document.querySelector("form").addEventListener("submit", function (e) {

  e.preventDefault();

  alert("Thank you for your message! I will contact you soon.");

  this.reset();

});